// logout.js
function logout() {
    // Clear user session or tokens (adjust as needed for your system)
    alert('You have been logged out.');
    window.location.href = '/login.html'; // Redirect to login page
}
